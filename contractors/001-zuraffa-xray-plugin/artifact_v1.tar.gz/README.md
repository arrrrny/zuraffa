# zuraffa x-ray plugin

DTD/VM-Service element mapping + an in-app debug overlay for Zuraffa apps.

Built against the public `zuraffa` repo at
https://github.com/arrrrny/zuraffa (cloned and read directly — no private
source was used or assumed).

## What's in this archive

```
lib/
  zuraffa.dart                          # patched: adds enableXRay() + exports
  src/core/api_bridge.dart              # patched: adds invokeLocally() (see below)
  src/plugins/xray/
    xray_plugin.dart                    # XRayPlugin registry, XRayConfig, XRayEndpointInfo
    xray_element_key.dart               # XRayElementKey — deterministic Key generator
    widgets/
      xray_overlay.dart                 # XRayOverlay — full-screen debug grid
      xray_section.dart                 # XRaySection — one collapsible panel
      xray_button.dart                  # XRayButton — action button + inline param form
      xray_host.dart                    # XRayHost — OverlayEntry mounting, zero-cost when disabled
test/
  xray_plugin_test.dart                 # acceptance tests (see mapping below)
example_app/
  main.dart                             # -> example/lib/main.dart in the zuraffa repo
  product_api_bridge.dart               # -> example/lib/src/api/bridges/product_api_bridge.dart
```

The two files under `example_app/` are drop-in replacements/additions for
files that already exist in the public `zuraffa` repo's `example/` app —
they're kept separate here (rather than a full second app tree) because
duplicating all of `example/`'s DI, cache, and domain layers would just be
re-shipping code that's already public and unmodified. Everything else in
`example/` (the `Todo`/`Product` entities, repositories, DI setup) is used
as-is from the repo.

## Run instructions

```bash
git clone https://github.com/arrrrny/zuraffa.git
cd zuraffa

# 1. Apply the two lib/ patches from this archive:
#    - lib/zuraffa.dart          (adds enableXRay + xray exports)
#    - lib/src/core/api_bridge.dart (adds invokeLocally)
# 2. Copy lib/src/plugins/xray/ into the repo's lib/src/plugins/xray/
# 3. Copy test/xray_plugin_test.dart into the repo's test/

flutter pub get
flutter test test/xray_plugin_test.dart

# Wire up the example app:
cp example_app/product_api_bridge.dart example/lib/src/api/bridges/product_api_bridge.dart
cp example_app/main.dart example/lib/main.dart
cd example
flutter pub get
flutter run
```

**I was not able to actually execute `flutter pub get` / `flutter test` /
`flutter run` myself** — this sandbox has no Flutter SDK installed and no
network access to `pub.dev` or Flutter's SDK archive (only a fixed
allowlist: GitHub, npm, PyPI, crates.io, apt). I cloned the real `zuraffa`
repo from GitHub and wrote every file against its actual public source
(not from memory or assumption), and reviewed each file by hand against
that source, but I want to be upfront that "tested" here means
"hand-reviewed against the real API surface," not "green CI run." Please
run `flutter test` yourself before relying on this — I'd rather say that
plainly than imply a verification I didn't perform.

## The DTD key scheme

Format: `xray::<elementType>::<domain>::<name>` (some element types drop
the domain segment — see `xray_element_key.dart` doc comments for every
case). Examples:

- `xray::usecase::barcode_listing::scanBarcode`
- `xray::endpoint::ext.zuraffa.product.getProduct`
- `xray::overlay::root`, `xray::overlay::close`

No UUIDs, no counters, no `hashCode` — every key is a pure function of
strings that already exist in the endpoint catalog (`domain`, `usecase`,
`method`), so an agent that already knows those names (e.g. from
`ext.zuraffa._list`) can predict the key without ever inspecting the
widget tree first:

```dart
await driver.tap(find.byValueKey('xray::usecase::barcode_listing::scanBarcode'));
```

## How the overlay reaches the `api` bridge without re-implementing RPC

This was the trickiest constraint in the spec: "X-Ray does NOT re-do RPC,"
but an overlay button is a widget running *inside the same isolate* as the
`ZuraffaApiBridge`-registered handler it wants to call — and
`dart:developer`'s `registerExtension` has no public "call this locally"
API, because service extensions are designed to be invoked by an
*external* VM Service client (DevTools, DTD, a driver test) over the wire.

Two honest options existed:
1. Add `package:vm_service` and have the app open a websocket back to its
   own VM Service to call itself — technically "not re-implementing RPC"
   in letter, but it's a new dependency and a loopback round trip just to
   call a function that's sitting in the same isolate.
2. Have `ZuraffaApiBridge` keep a small in-process `Map<String, Handler>`
   alongside the metadata it already tracks, and expose one new method,
   `invokeLocally(method, params)`, that looks the handler up and calls it
   directly — exactly the same function object a real VM Service call
   would have invoked, same JSON deserialization, same `Result`
   serialization, same everything. Only the network transport is skipped.

I went with (2) — it's the smaller, more honest change, it doesn't touch
the actual VM Service extension registration at all (external DTD clients
are completely unaffected and still go through the real protocol), and it
doesn't add a dependency. See the doc comment on
`ZuraffaApiBridge.invokeLocally` in the patched `api_bridge.dart` for the
full reasoning.

## Known limitations / things I'd flag before merging

- **Repositories/DataSources sections are currently always empty.** The
  `api` plugin's `ApiEndpoint` catalog only tracks UseCases (that's what
  `zfa api <Entity>` generates bridges for) — there's no existing runtime
  registry of Repository or DataSource instances to introspect. I left
  the `repositories`/`dataSources` config flags and section wiring in
  place per the interface contract, but they render nothing until Zuraffa
  grows a repository/data-source registry of its own to read from. I did
  not invent one, since that's a bigger design decision than this task's
  scope (and the spec explicitly said "prefer runtime" over inventing new
  code-gen surfaces).
- **`ZuraffaApiBridge.getRegisteredEndpoints()` is `@visibleForTesting`**
  in the current repo. `XRayPlugin.registeredEndpoints` calls it from
  production runtime code, which is a legitimate use (it's the same
  read-only catalog `ext.zuraffa._list` exposes externally) but you'll
  probably want to drop that annotation, or add a non-test-only variant,
  when you land this for real.
- `XRayHost` decides once (at first build) whether `XRayPlugin().enabled`
  is true and mounts an `Overlay` accordingly; it doesn't currently watch
  for `enableXRay` being called *after* the app is already running. This
  is why the example's `main.dart` calls `_initializeBridge()` (which
  calls `Zuraffa.enableXRay`) before `runApp()`, unlike the original
  example which called it after. Documented inline in that file.
- The inline param form treats every declared param as a single text
  field and submits `Map<String, String>` — fine for primitives and for
  bridges that accept a single JSON-blob `args` param (like
  `product_api_bridge.dart`'s `createProduct`), less ergonomic for bridges
  with several typed fields. Good enough for a debug tool; a v2 could use
  `params`' declared Dart type to pick a smarter input widget per field.

## Acceptance test mapping

| # | Case | Test(s) in `xray_plugin_test.dart` |
|---|---|---|
| 1 | Key determinism | `XRayElementKey` group |
| 2 | Overlay mounts | `overlay mounts and shows its root key` |
| 3 | Overlay doesn't mount in release | Not directly testable under `flutter test` (always non-release); `XRayPlugin.enable()`'s `kReleaseMode` guard is the actual gate — see its doc comment |
| 4 | UseCase buttons render (N endpoints → N buttons) | `renders one button per registered endpoint in UseCases` |
| 5 | Endpoint catalog renders | `catalog section shows all registered endpoints` |
| 6 | Section toggle | `repositories section does not appear when disabled` |
| 7 | Tap NoParams button dispatches to handler | `XRayPlugin.invoke() dispatches to the registered handler` |
| 8 | Tap params button opens form first | `button with params opens form instead of calling immediately` |
