import 'dart:convert';
import 'dart:developer' as developer;

import 'package:flutter/material.dart';

import '../xray_element_key.dart';
import '../xray_plugin.dart';

/// A single action button rendered inside an [XRaySection].
///
/// - Carries a deterministic [Key] from [XRayElementKey] so a DTD/VM
///   Service agent can find and tap it without inspecting the tree first.
/// - `NoParams`-style endpoints (`params` empty) call straight through.
/// - Endpoints with declared params open a small inline form first (see
///   [_XRayParamForm]) built from `endpoint.params` (name -> Dart type),
///   satisfying the "createProduct opens a form" behavior from the spec.
class XRayButton extends StatefulWidget {
  final Key elementKey;
  final String label;
  final XRayEndpointInfo endpoint;

  const XRayButton({
    required this.elementKey,
    required this.label,
    required this.endpoint,
    super.key,
  });

  @override
  State<XRayButton> createState() => _XRayButtonState();
}

class _XRayButtonState extends State<XRayButton> {
  bool _busy = false;

  Future<void> _run(Map<String, String> params) async {
    setState(() => _busy = true);
    try {
      final response = await XRayPlugin().invoke(
        widget.endpoint.method,
        params: params,
      );
      if (!mounted) return;
      _showResult(response);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showResult(developer.ServiceExtensionResponse response) {
    final raw = response.result ?? '';
    String message;
    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      message = decoded['status'] == 'success'
          ? 'OK: ${jsonEncode(decoded['data'])}'
          : 'Error: ${decoded['failure']?['message'] ?? decoded['failure']}';
    } catch (_) {
      message = raw;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
        ),
        duration: const Duration(seconds: 4),
      ),
    );
  }

  Future<void> _onPressed() async {
    if (widget.endpoint.params.isEmpty) {
      await _run(const {});
      return;
    }
    final values = await showDialog<Map<String, String>>(
      context: context,
      builder: (context) => _XRayParamForm(endpoint: widget.endpoint),
    );
    if (values != null) {
      await _run(values);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      key: widget.elementKey,
      onPressed: _busy ? null : _onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF2A2D34),
        foregroundColor: const Color(0xFFE6E6E6),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        alignment: Alignment.centerLeft,
      ),
      child: _busy
          ? const SizedBox(
              height: 14,
              width: 14,
              child: CircularProgressIndicator(strokeWidth: 2),
            )
          : Text(
              widget.label,
              overflow: TextOverflow.ellipsis,
            ),
    );
  }
}

/// Inline form for endpoints whose `params` map is non-empty.
///
/// One text field per declared param, submitted as a raw
/// `Map<String, String>` — matching the `Map<String, String>` shape every
/// generated bridge handler already expects (it's the same shape
/// `dart:developer` extension parameters always take).
class _XRayParamForm extends StatefulWidget {
  final XRayEndpointInfo endpoint;
  const _XRayParamForm({required this.endpoint});

  @override
  State<_XRayParamForm> createState() => _XRayParamFormState();
}

class _XRayParamFormState extends State<_XRayParamForm> {
  final Map<String, TextEditingController> _controllers = {};

  @override
  void initState() {
    super.initState();
    for (final name in widget.endpoint.params.keys) {
      _controllers[name] = TextEditingController();
    }
  }

  @override
  void dispose() {
    for (final c in _controllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFF1E2025),
      title: Text(
        widget.endpoint.usecase,
        style: const TextStyle(color: Colors.white),
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: widget.endpoint.params.entries.map((entry) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: TextField(
                key: XRayElementKey.formField(
                  widget.endpoint.method,
                  entry.key,
                ),
                controller: _controllers[entry.key],
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: '${entry.key} (${entry.value})',
                  labelStyle: const TextStyle(color: Colors.white54),
                ),
              ),
            );
          }).toList(),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          key: XRayElementKey.formSubmit(widget.endpoint.method),
          onPressed: () {
            final values = {
              for (final entry in _controllers.entries)
                entry.key: entry.value.text,
            };
            Navigator.of(context).pop(values);
          },
          child: const Text('Call'),
        ),
      ],
    );
  }
}
