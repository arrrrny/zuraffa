import 'package:flutter/material.dart';

import '../xray_element_key.dart';
import '../xray_plugin.dart';
import 'xray_overlay.dart';

/// Wraps the app's root widget so [XRayOverlay] can be inserted as a real
/// [OverlayEntry] sitting above everything else — without changing the
/// widget tree at all when x-ray is disabled.
///
/// ## Usage
///
/// ```dart
/// void main() {
///   ZuraffaApiBridge.init();
///   registerProductApiBridge();
///   Zuraffa.enableXRay(XRayConfig(useCases: true));
///
///   runApp(XRayHost(child: MyApp()));
/// }
/// ```
///
/// When [XRayPlugin.enabled] is `false` (release builds, or x-ray never
/// enabled), [build] returns `widget.child` directly — no [Overlay], no
/// extra widget, no extra `Key`s in the tree. This satisfies the
/// "must not interfere with the app's widget tree when disabled" contract:
/// there is nothing to interfere with when the check short-circuits.
class XRayHost extends StatefulWidget {
  final Widget child;
  const XRayHost({required this.child, super.key});

  @override
  State<XRayHost> createState() => _XRayHostState();
}

class _XRayHostState extends State<XRayHost> {
  final GlobalKey<OverlayState> _overlayKey = GlobalKey<OverlayState>();
  OverlayEntry? _xrayEntry;
  bool _panelOpen = true;

  @override
  void initState() {
    super.initState();
    if (XRayPlugin().enabled) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _insertPanel());
    }
  }

  void _insertPanel() {
    if (!XRayPlugin().enabled) return;
    _xrayEntry = OverlayEntry(
      builder: (context) =>
          XRayOverlay(config: XRayPlugin().config, onClose: _close),
    );
    _overlayKey.currentState?.insert(_xrayEntry!);
  }

  void _close() {
    _xrayEntry?.remove();
    _xrayEntry = null;
    if (mounted) setState(() => _panelOpen = false);
  }

  void _reopen() {
    setState(() => _panelOpen = true);
    _insertPanel();
  }

  @override
  Widget build(BuildContext context) {
    if (!XRayPlugin().enabled) return widget.child;

    return Overlay(
      key: _overlayKey,
      initialEntries: [
        OverlayEntry(builder: (context) => widget.child),
        OverlayEntry(
          builder: (context) =>
              _panelOpen ? const SizedBox.shrink() : _Launcher(onTap: _reopen),
        ),
      ],
    );
  }
}

/// Small floating re-open affordance shown once the overlay has been
/// closed, so x-ray isn't permanently dismissed for the rest of the debug
/// session.
class _Launcher extends StatelessWidget {
  final VoidCallback onTap;
  const _Launcher({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomRight,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Material(
            color: const Color(0xFF16181D),
            shape: const CircleBorder(),
            elevation: 4,
            child: InkWell(
              key: XRayElementKey.section('launcher'),
              customBorder: const CircleBorder(),
              onTap: onTap,
              child: const Padding(
                padding: EdgeInsets.all(12),
                child: Icon(Icons.biotech, color: Colors.white70, size: 20),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
